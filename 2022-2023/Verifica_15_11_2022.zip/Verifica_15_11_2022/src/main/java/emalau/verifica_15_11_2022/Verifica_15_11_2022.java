package emalau.verifica_15_11_2022;

public class Verifica_15_11_2022 {

    public static void main(String[] args) {
        Verifica_15_11_2022_JFrame VjF = new Verifica_15_11_2022_JFrame();
        VjF.setVisible(true);
    }
}
